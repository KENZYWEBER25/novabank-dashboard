import { useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, BarChart3, Bell, CreditCard, Eye, EyeOff, Home, LogOut, Menu, MoreHorizontal, Send, Settings, ShieldCheck, TrendingUp, Wallet, X } from 'lucide-react';

const transactions = [
  { name: 'Netflix', type: 'Subscription', amount: '-$15.99', date: 'Sep 06, 2026', icon: 'N' },
  { name: 'Sarah Johnson', type: 'Transfer received', amount: '+$850.00', date: 'Sep 05, 2026', icon: 'S' },
  { name: 'Whole Foods Market', type: 'Groceries', amount: '-$126.42', date: 'Sep 04, 2026', icon: 'W' },
  { name: 'Stripe Payout', type: 'Income', amount: '+$2,450.00', date: 'Sep 02, 2026', icon: 'S' },
  { name: 'Uber', type: 'Transportation', amount: '-$32.80', date: 'Sep 01, 2026', icon: 'U' },
];

function App() {
  const [active, setActive] = useState('Overview');
  const [showBalance, setShowBalance] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');

  const submitTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipient.trim() || !amount || Number(amount) <= 0) { setNotice('Enter a recipient and a valid amount.'); return; }
    setNotice(`Transfer of ${Number(amount).toFixed(2)} scheduled to ${recipient}.`);
    setRecipient(''); setAmount('');
  };

  const nav = [
    ['Overview', Home], ['Transactions', BarChart3], ['Cards', CreditCard], ['Payments', Send], ['Settings', Settings]
  ] as const;

  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark">N</div><span>NovaBank</span><button className="close-menu" onClick={() => setMenuOpen(false)}><X size={20}/></button></div>
      <div className="profile"><div className="avatar">MK</div><div><strong>Maxwell K.</strong><small>Personal account</small></div></div>
      <nav>{nav.map(([label, Icon]) => <button key={label} className={active === label ? 'nav-item active' : 'nav-item'} onClick={() => {setActive(label);setMenuOpen(false);}}><Icon size={19}/><span>{label}</span></button>)}</nav>
      <div className="sidebar-bottom"><div className="security"><ShieldCheck size={18}/><div><strong>Protected</strong><small>Bank-grade security</small></div></div><button className="logout"><LogOut size={18}/> Sign out</button></div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="menu-btn" onClick={() => setMenuOpen(true)}><Menu/></button><div><p className="eyebrow">Sunday, September 7, 2026</p><h1>Good evening, Maxwell</h1></div><div className="top-actions"><button className="icon-btn"><Bell size={20}/><span className="dot"/></button><div className="top-avatar">MK</div></div></header>
      {notice && <div className="notice">{notice}<button onClick={() => setNotice('')}>×</button></div>}
      {active === 'Overview' && <>
        <section className="hero-grid">
          <div className="balance-card"><div className="card-top"><span>Total balance</span><button onClick={() => setShowBalance(!showBalance)}>{showBalance ? <EyeOff size={18}/> : <Eye size={18}/>} {showBalance ? 'Hide' : 'Show'}</button></div><div className="balance">{showBalance ? '$24,680.42' : '••••••••'}</div><div className="balance-meta"><span>Available balance</span><span>+$2,450 this month</span></div><div className="balance-actions"><button onClick={() => setTransferOpen(true)}><Send size={17}/> Transfer</button><button onClick={() => setNotice('Deposit workflow is ready for bank integration.') }><Wallet size={17}/> Deposit</button></div></div>
          <div className="insight-card"><div className="card-title"><div><span>Monthly spending</span><strong>$3,284.16</strong></div><span className="positive"><TrendingUp size={15}/> 8.4%</span></div><div className="chart"><div className="chart-line"><i/><i/><i/><i/><i/><i/><i/><i/></div></div><div className="chart-labels"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div></div>
        </section>
        <section className="content-grid"><div className="panel"><div className="panel-head"><div><h2>Recent transactions</h2><p>Your latest account activity</p></div><button className="text-btn" onClick={() => setActive('Transactions')}>View all</button></div><div className="transaction-list">{transactions.map(t => <div className="transaction" key={t.name}><div className="transaction-icon">{t.icon}</div><div className="transaction-main"><strong>{t.name}</strong><small>{t.type} · {t.date}</small></div><strong className={t.amount.startsWith('+') ? 'amount positive-text' : 'amount'}>{t.amount}</strong><button className="more"><MoreHorizontal size={18}/></button></div>)}</div></div><div className="panel quick-panel"><div className="panel-head"><div><h2>Quick actions</h2><p>Manage your money</p></div></div><button onClick={() => setTransferOpen(true)}><Send/><span><strong>Send money</strong><small>Transfer to another account</small></span><ArrowUpRight/></button><button onClick={() => setNotice('Card controls opened.')}><CreditCard/><span><strong>Manage cards</strong><small>Freeze, replace or view cards</small></span><ArrowUpRight/></button><button onClick={() => setNotice('Insights opened.')}><BarChart3/><span><strong>View insights</strong><small>Understand your spending</small></span><ArrowUpRight/></button></div></section>
        <section className="bottom-grid"><div className="panel"><div className="panel-head"><div><h2>My cards</h2><p>Primary debit card</p></div><button className="more"><MoreHorizontal/></button></div><div className="bank-card"><div className="chip"/><span className="visa">VISA</span><strong>•••• 4821</strong><small>MAXWELL KENECHUKWU</small></div></div><div className="panel activity"><h2>Financial health</h2><div className="health-row"><div className="health-ring">82</div><div><strong>Looking good</strong><p>Your spending is 12% lower than last month.</p></div></div><div className="health-stat"><span>Saving goal</span><strong>68%</strong></div><div className="progress"><i/></div></div></section>
      </>}
      {active !== 'Overview' && <section className="panel page-panel"><div className="panel-head"><div><h2>{active}</h2><p>This section is ready for the next product iteration.</p></div></div><div className="empty-state"><div className="empty-icon"><CreditCard/></div><h3>{active} workspace</h3><p>Interactive banking functionality can be connected to a secure backend and real financial APIs when this concept moves beyond the portfolio demo.</p><button onClick={() => setActive('Overview')}>Back to overview</button></div></section>}
    </main>
    {transferOpen && <div className="modal-backdrop"><div className="modal"><div className="modal-head"><div><h2>Send money</h2><p>Simulated transfer for the portfolio demo.</p></div><button onClick={() => setTransferOpen(false)}><X/></button></div><form onSubmit={submitTransfer}><label>Recipient<input value={recipient} onChange={e => setRecipient(e.target.value)} placeholder="Name or account"/></label><label>Amount (USD)<input value={amount} onChange={e => setAmount(e.target.value)} inputMode="decimal" placeholder="0.00"/></label><button className="primary" type="submit">Review transfer</button></form></div></div>}
  </div>;
}

export default App;